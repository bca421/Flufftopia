# events.py
import random
from combat import combat

events = {
    "forest": [
        "You encounter a wild animal! A wolf emerges from the bushes, growling menacingly.",
        "You find a hidden treasure! An old chest covered in moss sits beneath a tree.",
        "You get lost! The forest seems to close in around you, and you can't find your way back."
    ],
    "village": [
        "You meet a friendly villager. An old man with a kind face offers you some advice.",
        "You find a market selling goods. The air is filled with the scent of fresh bread and spices.",
        "You rest at the inn. The innkeeper welcomes you warmly and offers you a room for the night."
    ],
    "cave": [
        "You find a glowing crystal embedded in the cave wall, its light illuminating the darkness.",
        "You encounter a bat! It flutters around your head, startling you.",
        "You discover an underground river, its water sparkling in the dim light."
    ],
    "castle": [
        "You find a hidden passage behind a tapestry, leading to a secret room.",
        "You encounter a ghost! A translucent figure floats through the air, moaning softly.",
        "You discover a treasure chest filled with gold coins and jewels."
    ],
    "lake": [
        "You find a fishing rod lying on the shore, perfect for catching fish.",
        "You encounter a magical creature. A unicorn drinks from the lake, its horn shimmering.",
        "You discover a small boat tied to a tree, just waiting for someone to take it out on the water."
    ]
}

items = {
    "forest": ["mushrooms", "berries", "wooden stick"],
    "village": ["bread", "potion", "map"],
    "cave": ["crystal shard", "ancient coin", "torch"],
    "castle": ["gold coin", "sword", "shield"],
    "lake": ["fish", "water bottle", "boat"]
}

enemies = {
    "wolf": {"name": "Wolf", "health": 50, "strength": 10, "defense": 5, "loot": ["wolf pelt", "fang"]},
    "bat": {"name": "Bat", "health": 20, "strength": 5, "defense": 2, "loot": ["bat wing", "guano"]},
    "ghost": {"name": "Ghost", "health": 40, "strength": 15, "defense": 5, "loot": ["ectoplasm", "ancient coin"]}
}

def random_event(location, player):
    event = random.choice(events[location])
    print(event)

    if "wild animal" in event or "bat" in event or "ghost" in event:
        enemy_name = "wolf" if "wolf" in event else "bat" if "bat" in event else "ghost"
        combat(player, enemies[enemy_name])
    elif "hidden treasure" in event:
        item = random.choice(items[location])
        player["inventory"].append(item)
        print(f"You open the chest and find a {item}!")
    elif "friendly villager" in event:
        player["health"] += 10
        print("The old man gives you a healing potion. You gain 10 health points.")
    elif "market" in event:
        item = random.choice(items[location])
        player["inventory"].append(item)
        print(f"You buy a {item} from the market.")
    elif "glowing crystal" in event:
        item = "glowing crystal"
        player["inventory"].append(item)
        print("You carefully extract the glowing crystal from the cave wall and add it to your inventory.")
    elif "underground river" in event:
        print("You drink from the underground river, feeling refreshed and gaining 5 health points.")
        player["health"] += 5
    elif "fishing rod" in event:
        item = "fishing rod"
        player["inventory"].append(item)
        print("You pick up the fishing rod and add it to your inventory.")
    elif "magical creature" in event:
        print("The unicorn blesses you with good fortune. You gain 10 health points.")
        player["health"] += 10
    elif "small boat" in event:
        item = "small boat"
        player["inventory"].append(item)
        print("You untie the boat and add it to your inventory.")
