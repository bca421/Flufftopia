# game_intro.py
def game_intro():
    print("Welcome to the adventure game!")
    print("In a land of mystery and magic, you will embark on a journey like no other.")
    print("Explore ancient ruins, enchanted forests, and hidden villages.")
    print("Uncover secrets long forgotten and treasures untold.")
    print("Your goal is to survive, grow stronger, and uncover the ultimate treasure.")
    print("Good luck, brave adventurer!\n")
