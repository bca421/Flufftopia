# Define a list of weapons with random names and damage values for Flufftopia.
weapons = [
    {"name": "Flame Sword", "damage": 15},
    {"name": "Ice Axe", "damage": 12},
    {"name": "Storm Bow", "damage": 10},
    {"name": "Shadow Dagger", "damage": 8},
    {"name": "Light Mace", "damage": 14},
    {"name": "Nature Staff", "damage": 9},
    {"name": "Thunder Crossbow", "damage": 11},
    {"name": "Wind Spear", "damage": 13},
    {"name": "Earth Halberd", "damage": 16},
    {"name": "Sun Warhammer", "damage": 18}
]
