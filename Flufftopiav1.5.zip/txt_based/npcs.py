# Define a list of NPCs with random names and dialogues for Flufftopia.
npcs = [
    {"name": "Arin the Wise", "dialogue": "Hello traveler!"},
    {"name": "Borok the Merchant", "dialogue": "Would you like to buy something?"},
    {"name": "Cynric the Blacksmith", "dialogue": "I can forge weapons for you."},
    {"name": "Dagna the Healer", "dialogue": "I can heal your wounds."},
    {"name": "Eldrin the Guard", "dialogue": "Stay out of trouble."},
    {"name": "Finn the Farmer", "dialogue": "It's a hard day's work."},
    {"name": "Gilda the Innkeeper", "dialogue": "Need a room for the night?"},
    {"name": "Haldor the Fisherman", "dialogue": "Caught any big ones lately?"},
    {"name": "Ivar the Bard", "dialogue": "Shall I sing you a song?"},
    {"name": "Jorvik the Alchemist", "dialogue": "I have potions for every need."},
    {"name": "Kael the Scholar", "dialogue": "Knowledge is power."},
    {"name": "Lorna the Thief", "dialogue": "Keep an eye on your belongings."},
    {"name": "Mara the Hunter", "dialogue": "The forest is my domain."},
    {"name": "Nissa the Wizard", "dialogue": "Magic is the key to all things."},
    {"name": "Orla the Priest", "dialogue": "May the gods watch over you."}
]
